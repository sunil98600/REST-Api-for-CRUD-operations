const express = require('express');
const users = require('./MOCK_DATA.json');
// const mongoose = require('mongoose');
const userRoute = require('./routes/user');
const { connectMongoDB } = require('./connection');
const fs = require('fs');
const { timeStamp } = require('console');
const app = express();
const PORT = 8000;

//connection
connectMongoDB('mongodb://localhost:27017/myfirstnodeapp').then(() => console.log('MongoDB Connected'));
// mongoose.connect('mongodb://localhost:27017/myfirstnodeapp')
// .then(() => console.log("MongoDB connected"))
// .catch((err) => console.log("Mongo error",err) );
//schema 
// const userSchema = mongoose.Schema({
//     firstName: {
//         type : String,
//         required : true
//     },
//     lastName: {
//         type : String
//     },
//     email: {
//         type : String,
//         required : true,
//         unique : true
//     },
//     jobTitle: {
//         type : String
//     }
// },
// {
//     timestamps : true    
// });

//  const User = mongoose.model('user', userSchema);
//middleware-plugins
app.use(express.urlencoded({extended : false}));
app.use((req,res,next) =>{
    res.setHeader("X-Myname", "Sunil Patil");
    console.log("Hello from middleware");
    next();
})
app.use((req,res,next) =>{
    console.log("Hello from middleware 2");
    next();
})

// routes
app.use('/users',userRoute);
// app.get('/users',async(req,res)=>{
//     const alldbusers = await User.find();
//     const html = `
//     <ul> ${alldbusers.map(user => `<li>${user.firstName} - ${user.email}</li> `).join("")}
//     </ul>
//     `;
//     return res.send(html);
// });

// //REST API

// // merged routes
// app.route('/api/users/:id').get(async(req,res)=>{
//     // const id = Number(req.params.id);
//     // user = users.find((user) => user.id === id);
//     const user = await User.findById(req.params.id);
//     if(!user) return res.status(404).json({error : "Id not found"});
//     res.json(user);
// })
// .patch(async(req,res) =>{
//     // Edit patch
//     // const id = Number(req.params.id);
//     // userindex = users.find((user) => user.id === id);
//     // if(userindex !== -1){
//     //     const updateduser = {...users[userindex], ...req.body};
//     //     users[userindex] = updateduser;
//     //     console.log(updateduser);
//     //     fs.writeFile('./MOCK_DATA.json',JSON.stringify(users),(err,data) => {
//     //         res.json({status : 'success'});
//     //     })
//     // }
//     await User.findByIdAndUpdate(req.params.id, { lastName: "Changed"});
//     res.json({msg:"Successs"});

// }).delete(async(req,res) =>{
//     // Edit delete
//     // const id = Number(req.params.id);
//     // userindex = users.find((user) => user.id === id);
//     // if(userindex !== -1){
//     //     users.splice(userindex,1);
//     //     fs.writeFile('./MOCK_DATA.json',JSON.stringify(users),(err,data) =>{
//     //         return res.json({status : 'Pending'});
//     //     })
//     // }
//     await User.findByIdAndDelete(req.params.id);
//     res.json( { status : " Success"} );
    
// });

// // separate routes
// app.get('/api/users',async(req,res)=>{
//     const alldbusers = await User.find();
//     return res.json(alldbusers);
// });
// // app.get('/api/users/:id',(req,res)=>{
// //     const id = Number(req.params.id);
// //     user = users.find((user) => user.id === id);
// //     res.json(user);
// // });


// app.post('/api/users',async (req,res)=>{
//     // Edit the post request for users
//     const body =req.body;
//     users.push({...body ,id: users.length+1 });
//     if(!body || !body.first_name || !body.last_name || !body.email || !body.job_title){
//         res.status(400).json({error:" enter all the fields"})
//     }
//     const result = await User.create({
//         firstName : body.first_name,
//         lastName : body.last_name,
//         email : body.email,
//         jobTitle : !body.job_title
//     });

//         return res.status(201).json({msg : "Success"});

// });

// app.patch('/api/users/:id',(req,res) =>{
//     // Edit patch
//     return res.json({status : 'Pending'});
// });
// app.delete('/api/users/:id',(req,res) =>{
//     // Edit patch
//     return res.json({status : 'Pending'});
// })



app.listen(PORT,()=> console.log(`server started on port ${PORT}`));