const User = require('../models/user');

async function handlegetrequest(req,res){
    const alldbusers = await User.find();
    return res.json(alldbusers);
}

async function handlecreateuserrequest(req,res){
    const body =req.body;
    if(!body || !body.first_name || !body.last_name || !body.email || !body.job_title){
        res.status(400).json({error:" enter all the fields"})
    }
    const result = await User.create({
        firstName : body.first_name,
        lastName : body.last_name,
        email : body.email,
        jobTitle : !body.job_title
    })

        return res.status(201).json({msg : "Success" , id : result._id});
}

async function handlefindById(req,res){
    const user = await User.findById(req.params.id);
    if(!user) return res.status(404).json({error : "Id not found"});
    res.json(user);
}
async function handlefindByIdAndUpdate(req,res){
    await User.findByIdAndUpdate(req.params.id, { lastName: "Changed"});
    res.json({msg:"Successs"});
}
async function handlefindByIdAndDelete(req,res){
    await User.findByIdAndDelete(req.params.id);
    res.json( { status : " Success"} );
}




module.exports = {
    handlegetrequest,
    handlecreateuserrequest,
    handlefindById,
    handlefindByIdAndUpdate,
    handlefindByIdAndDelete
    
}