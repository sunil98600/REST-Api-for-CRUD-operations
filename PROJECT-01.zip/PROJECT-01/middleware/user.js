async function logreqres(filename){
    (req,res,next) => {
        
    }
}