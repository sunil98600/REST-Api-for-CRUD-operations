const express = require('express');
const router = express.Router();
const {handlegetrequest, handlecreateuserrequest,handlefindById,handlefindByIdAndUpdate, handlefindByIdAndDelete} = require('../controller/user');



//REST API
router.route('/').get(handlegetrequest)
.post(handlecreateuserrequest)

// merged routes
router.route('/:id').get(handlefindById)
.patch(handlefindByIdAndUpdate)
.delete(handlefindByIdAndDelete)

module.exports = router;